# Logical operators

5 > 3 # greater than
5 >= 3 # greater than or equal
5 < 3 # less than
5 <= 3 # less than or equal
5 == 3 # equal
5 != 3 # not equal

"B" == "A" # also for characters, depends on coding

!(TRUE) # NOT
TRUE | FALSE # OR
TRUE & FALSE # AND
