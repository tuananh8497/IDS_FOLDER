page.limit <- 10
for(count in 1:page.limit){
  print(paste("page numbber is:", count))
}
print("Flipping the pages has finished")
