page.limit <- 10
count <- 0
while(count < page.limit){
  count <- count + 1
  print(paste("page numbber is:", count))
}
print("Flipping the pages has finished")
