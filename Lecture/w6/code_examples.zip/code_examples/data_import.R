library(readr)
data <- readr::read_csv("data/data_sample.csv")
data
