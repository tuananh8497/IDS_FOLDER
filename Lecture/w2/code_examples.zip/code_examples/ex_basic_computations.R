2 + 3

6 - 10

3 * 4

10 / 4

12 ** 4

log(1:5)

print("Introduction to Data Science.")

print(paste("I am ", 25, "years old!"))

5 == 2

30 > 20

10 <= 2

5 != 4

readline(prompt = "what is your age?")

age

12 ^ 4
