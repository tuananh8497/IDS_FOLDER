# Load the 'nycflights13' dataset into a frame and then find all flights that:
library(tidyverse)
library(nycflights13)

# 1- What month had the highest proportion of cancelled flights? 
cancelled_flights <- filter(flights, is.na(air_time)) 
grouped_by_month <- group_by(cancelled_flights, month) 
counts_per_month <- summarise(grouped_by_month, count = n()) 
highest_prop <- summarise(counts_per_month, max_month= month[which.max(count)], max_value= max(count))

# 2- What month had the lowest? 
month_with_min <- summarise(counts_per_month, month= which.min(count))
month_with_min
